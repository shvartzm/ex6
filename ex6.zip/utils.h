#ifndef UTILS_H
#define UTILS_H

int getInt(const char* prompt);
char* getString(const char* prompt);
int giveDesX(int x, int dir);
int giveDesY(int y, int dir);

#endif
